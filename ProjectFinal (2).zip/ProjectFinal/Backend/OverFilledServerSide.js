// code will save the highscore to the server incase the player resets their cookies

const express = require('express');
const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const cors = require('cors');

const app = express();
const port = 3000;
const adapter = new FileSync('db.json');
const db = low(adapter);

db.defaults({ highscore: 0 }).write();
app.use(express.json());
app.use(cors());

app.get('/highscore', (req, res) => {
  res.json({ highscore: db.get('highscore').value() });
});

app.post('/highscore', (req, res) => {
  const { score } = req.body;
  if (score > db.get('highscore').value()) {
    db.set('highscore', score).write();
    res.json({ message: 'High score updated!' });
  } else {
    res.json({ message: 'Score not high enough to update' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
